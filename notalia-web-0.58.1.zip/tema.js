/* global localStorage, window, document */
// Apariencia (ADR 0081): antes de pintar nada, pone en <html data-tema> «claro» u «oscuro» según lo elegido
// en Ajustes › Apariencia (en este dispositivo) o, en «Automática», según el sistema. Va aparte y sin
// «module» para que se ejecute antes del primer pintado; la app lo mantiene al día (src/logica/tema.ts).
(function () {
  var elegido = null;
  try {
    elegido = localStorage.getItem('notalia-tema');
  } catch {
    /* sin almacenamiento: automática */
  }
  var oscuroSistema = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  document.documentElement.dataset.tema =
    elegido === 'claro' || elegido === 'oscuro' ? elegido : oscuroSistema ? 'oscuro' : 'claro';
})();
