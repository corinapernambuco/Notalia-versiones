/* global self, URL */
// Va dentro del service worker de la app (workbox `importScripts`). Arregla a quien abrió Notalia antes del
// 17-11-2026: su service worker de entonces servía la app en cualquier dirección, también en /blog/. El nuevo
// se descarga, pero se queda esperando a «Actualizar» en la app, y quien solo lee el blog nunca lo ve.
// Si todas las pestañas abiertas de este sitio son del blog (o de páginas que no son la app), el nuevo se
// activa en el acto y las recarga: ya se ve el blog. Si hay una pestaña de la app, espera, como siempre (para
// no recargar la app a mitad de trabajo).
const NO_ES_LA_APP = /^\/(blog(\/|$)|acerca|privacidad|beta|sitemap\.xml|robots\.txt)/;

const soloFueraDeLaApp = async () => {
  const pestanas = await self.clients.matchAll({ type: 'window', includeUncontrolled: true });
  return pestanas.length > 0 && pestanas.every((p) => NO_ES_LA_APP.test(new URL(p.url).pathname));
};

let recargar = false;
self.addEventListener('install', (e) => {
  e.waitUntil(
    soloFueraDeLaApp().then((solo) => {
      if (!solo) return;
      recargar = true;
      return self.skipWaiting();
    }),
  );
});

self.addEventListener('activate', (e) => {
  if (!recargar) return;
  // Se activa ya (no se espera a las recargas: si una tardara, todo quedaría esperando) y después se recargan
  // las pestañas atascadas.
  const listo = self.clients.claim();
  e.waitUntil(listo);
  listo
    .then(() => self.clients.matchAll({ type: 'window' }))
    .then((pestanas) => {
      for (const p of pestanas)
        if (NO_ES_LA_APP.test(new URL(p.url).pathname)) p.navigate(p.url).catch(() => undefined);
    });
});
